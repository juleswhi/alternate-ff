<div align="center">

# Alternate

Vim Alternate Buffer In Firefox

</div>

## Install

- Go to `about:debugging`
- Click on `This Firefox`
- Click on `Load Temporary Add-on`
- Select the `manifest.json`

## Usage

*Alternate* uses the vim keybinding for alternate buffer, `Ctrl+^`

__NB__ Currently there is no way to change the keybind
